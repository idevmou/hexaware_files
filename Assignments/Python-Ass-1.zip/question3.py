import pandas as pd
import pyodbc

# db connection
conn_db = pyodbc.connect('Driver={SQL Server};'
                         'Server=Mouli-Sankar;'
                         'Database=Hexaware;'
                         'Trusted_Connection=yes;'
                         )

cursor = conn_db.cursor()

query1 = ('''
                    SELECT *
                    FROM [Hexaware].[dbo].[input_assign_learn_from_vinit]
                    WHERE GroupName = 'Research and Development'
                '''
          )

# load a data into dataframe
df = pd.read_sql(query1, conn_db)

# new database in sql server
print(df)

for row in df.itertuples():
    cursor.execute('''
                        insert into [dbo].[input_assign_learn_from_vinit_R&D] (DepartmentID, Name, GroupName)
                        values(?,?,?)
                        ''',
                   row.DepartmentID,
                   row.Name,
                   row.GroupName
                   )

conn_db.commit()
conn_db.close()
