# Using Python read the attached file in Python and print it’s output.

# importing the pandas
import pandas as pd

df = pd.read_csv('input_assign_learn_from_vinit.csv', delimiter=',')

print(df)
