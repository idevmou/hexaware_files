# creating connection

import pyodbc
# import pandas as pd

# Connection to SQL Server Database
conn_db = pyodbc.connect('Driver={SQL Server};'
                         'Server=Mouli-Sankar;'
                         'Database=Hexaware;'
                         'Trusted_Connection=yes;'
                         )

cursor = conn_db.cursor()

# Create Table having name as learn_python_batch03
df = cursor.execute('''
                SELECT * FROM [hexaware].[dbo].[input_assign_learn_from_vinit_R&D]
''')

df = cursor.fetchall()

for row in df:
    print(row)
