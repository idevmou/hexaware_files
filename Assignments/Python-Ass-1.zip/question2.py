# Load data in table (new) in SQL Server Database

import pyodbc
import pandas as pd

# Connection to SQL Server Database
conn_db = pyodbc.connect('Driver={SQL Server};'
                         'Server=Mouli-Sankar;'
                         'Database=Hexaware;'
                         'Trusted_Connection=yes;'
                         )

cursor = conn_db.cursor()

# Create Table having name as learn_python_batch03
cursor.execute('''
                create table [hexaware].[dbo].[input_assign_learn_from_vinit]
                (
                    DepartmentID int,
                    Name varchar(100),
                    GroupName varchar(100)
                )
''')

# Read text File
df = pd.read_csv("input_assign_learn_from_vinit.csv", delimiter=",")
print("File has following data \n", df)

# Insert Values from Flat File to Database
for row in df.itertuples():
    cursor.execute('''
                        insert into [dbo].[input_assign_learn_from_vinit] (DepartmentID, Name, GroupName)
                        values(?,?,?)
                        ''',
                   row.DepartmentID,
                   row.Name,
                   row.GroupName
                   )

conn_db.commit()
conn_db.close()

